*****************************************************************************
** ChibiOS/RT port for ARM-Cortex-M4 Freedom Board K20D50M.                **
*****************************************************************************

** TARGET **

The demo runs on an Freescale Freedom K20D50M board.

** The Demo **


** Build Procedure **

The demo has been tested by using the free Codesourcery GCC-based toolchain
and YAGARTO. just modify the TRGT line in the makefile in order to use
different GCC toolchains.
